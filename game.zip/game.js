// Игровые переменные
let coins = 0;          
let clickPower = 1;     
let passiveIncome = 0;  

let upgClickCost = 10;
let upgClickLevel = 1;
let upgFarmCost = 50;
let upgFarmLevel = 0;

// Элементы интерфейса
const balanceText = document.getElementById('balance-text');
const statsText = document.getElementById('stats-text');
const manulButton = document.getElementById('manul-button');

const btnClick = document.getElementById('btn-click');
const btnFarm = document.getElementById('btn-farm');
const btnAd = document.getElementById('btn-ad');

const lblClickLvl = document.getElementById('lbl-click-lvl');
const lblClickCost = document.getElementById('lbl-click-cost');
const lblFarmLvl = document.getElementById('lbl-farm-lvl');
const lblFarmCost = document.getElementById('lbl-farm-cost');

function formatCoins(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

function updateUI() {
    if (balanceText) balanceText.innerText = formatCoins(coins);
    if (statsText) statsText.innerText = `Клик: +${clickPower} | Секунда: +${passiveIncome}`;
    
    if (lblClickLvl) lblClickLvl.innerText = upgClickLevel;
    if (lblClickCost) lblClickCost.innerText = formatCoins(upgClickCost);
    if (lblFarmLvl) lblFarmLvl.innerText = upgFarmLevel;
    if (lblFarmCost) lblFarmCost.innerText = formatCoins(upgFarmCost);
    
    if (btnClick) btnClick.disabled = coins < upgClickCost;
    if (btnFarm) btnFarm.disabled = coins < upgFarmCost;
}

function createFloatingText(x, y, text) {
    const clickText = document.createElement('div');
    clickText.classList.add('floating-click-text');
    clickText.innerText = text;
    clickText.style.left = `${x - 15}px`;
    clickText.style.top = `${y - 20}px`;
    document.body.appendChild(clickText);
    setTimeout(() => { clickText.remove(); }, 600);
}

function processClick(e) {
    coins += clickPower;
    let clientX = e.clientX;
    let clientY = e.clientY;
    
    if (e.changedTouches && e.changedTouches.length > 0) {
        clientX = e.changedTouches.clientX;
        clientY = e.changedTouches.clientY;
    }
    createFloatingText(clientX, clientY, `+${clickPower}`);
    updateUI();
}

if (manulButton) manulButton.addEventListener('click', processClick);

if (btnClick) {
    btnClick.addEventListener('click', () => {
        if (coins >= upgClickCost) {
            coins -= upgClickCost;
            upgClickLevel += 1;
            clickPower = upgClickLevel;
            upgClickCost = Math.floor(upgClickCost * 1.5);
            saveGame();
            updateUI();
        }
    });
}

if (btnFarm) {
    btnFarm.addEventListener('click', () => {
        if (coins >= upgFarmCost) {
            coins -= upgFarmCost;
            passiveIncome += 2;
            upgFarmLevel += 1;
            upgFarmCost = Math.floor(upgFarmCost * 1.6);
            saveGame();
            updateUI();
        }
    });
}

if (btnAd) btnAd.addEventListener('click', showVKRewardVideoAd);

// Пассивный доход
setInterval(() => {
    coins += passiveIncome;
    updateUI();
}, 1000);


// --- СИСТЕМА СОХРАНЕНИЙ (ОБЛАКО VK + РЕЗЕРВ ЛОКАЛЬНО) ---
function saveGame() {
    const gameData = { coins, clickPower, passiveIncome, upgClickCost, upgClickLevel, upgFarmCost, upgFarmLevel };
    const stringData = JSON.stringify(gameData);
    
    // 1. Сохраняем локально в браузер
    localStorage.setItem('manulKombatVK_save', stringData);
    
    // 2. Отправляем в облако ВКонтакте через VK Bridge
    if (typeof vkBridge !== 'undefined') {
        vkBridge.send('VKWebAppStorageSet', {
            key: 'manul_save',
            value: stringData
        }).then(() => console.log('Успешно сохранено в облако VK!'))
          .catch(e => console.error('Ошибка облака VK:', e));
    }
}

function loadGame() {
    // 1. Сначала пробуем загрузить из облака ВК
    if (typeof vkBridge !== 'undefined') {
        vkBridge.send('VKWebAppStorageGet', { keys: ['manul_save'] })
        .then(data => {
            if (data.keys && data.keys[0].value) {
                applyParsedData(data.keys[0].value);
                console.log('Загружено из облака VK');
            } else {
                loadLocalBackup();
            }
        }).catch(() => loadLocalBackup());
    } else {
        loadLocalBackup();
    }
}

function loadLocalBackup() {
    const savedData = localStorage.getItem('manulKombatVK_save');
    if (savedData) applyParsedData(savedData);
}

function applyParsedData(jsonString) {
    try {
        const data = JSON.parse(jsonString);
        coins = Number(data.coins) || 0; 
        clickPower = Number(data.clickPower) || 1; 
        passiveIncome = Number(data.passiveIncome) || 0;
        upgClickCost = Number(data.upgClickCost) || 10; 
        upgClickLevel = Number(data.upgClickLevel) || 1;
        upgFarmCost = Number(data.upgFarmCost) || 50; 
        upgFarmLevel = Number(data.upgFarmLevel) || 0;
    } catch(e) { console.error(e); }
    updateUI();
}


// --- ИНТЕГРАЦИЯ VK РЕКЛАМЫ ---
if (typeof vkBridge !== 'undefined') {
    // Инициализация VK Bridge
    vkBridge.send('VKWebAppInit')
    .then(() => {
        console.log('VK Bridge готов!');
        loadGame(); // Загружаем игру только после инициализации СДК
        
        // Показываем межстраничную рекламу при старте
        vkBridge.send('VKWebAppShowNativeAds', { ad_format: 'interstitial' }).catch(e => console.log(e));
    });

    // Автоматический баннер раз в 2 минуты
    setInterval(() => {
        vkBridge.send('VKWebAppShowNativeAds', { ad_format: 'interstitial' }).catch(e => console.log(e));
    }, 120000);
} else {
    // Локальный запуск на ПК без ВК
    setTimeout(loadGame, 100);
}

function showVKRewardVideoAd() {
    if (typeof vkBridge !== 'undefined') {
        vkBridge.send('VKWebAppShowNativeAds', { ad_format: 'reward' })
        .then(data => {
            if (data.result) {
                // Успешный просмотр
                coins += 500;
                saveGame();
                updateUI();
                alert("Бонус +500 коинов зачислен!");
            }
        }).catch(e => alert("Реклама пока недоступна"));
    } else {
        // Тест на компьютере
        coins += 500;
        saveGame();
        updateUI();
        createFloatingText(window.innerWidth / 2, window.innerHeight / 2, "+500 Бонус!");
    }
}

setInterval(saveGame, 5000); // Резервный таймер автосохранения







